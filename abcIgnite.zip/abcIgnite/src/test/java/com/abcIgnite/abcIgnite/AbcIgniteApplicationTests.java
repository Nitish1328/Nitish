package com.abcIgnite.abcIgnite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbcIgniteApplicationTests {

	@Test
	void contextLoads() {
	}

}
