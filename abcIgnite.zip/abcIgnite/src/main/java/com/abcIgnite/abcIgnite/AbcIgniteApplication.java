package com.abcIgnite.abcIgnite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbcIgniteApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbcIgniteApplication.class, args);
	}

}
